--
-- Author: Your Name
-- Date: 2016-12-07 16:32:50
--

cc.exports.ClientParamConfig = {}

ClientParamConfig.WEIXIN_SHARE_URL_ANDROID = 4030 --安卓分享链接
ClientParamConfig.WEIXIN_SHARE_URL_IOS = 4031     --ios分享链接

ClientParamConfig.WEIXIN_SHARE_CONTENT = 4032 --分享内容
ClientParamConfig.WEIXIN_SHARE_FRIEND_CONTENT = 4033     --分享到朋友圈的内容