cc.exports.niuniu_str_table = {}
niuniu_str_table.wxpay = "微信支付"
niuniu_str_table.alipay = "支付宝支付"
niuniu_str_table.select_pay = "是否花费%元购买该道具"

niuniu_str_table.room_id = "房间号:%s"
niuniu_str_table.base_score = "底分:%s"

niuniu_str_table.have_niu = "有牛哦，请仔细找找！"
niuniu_str_table.no_niu = "点数错误！"
niuniu_str_table.total_info = "通杀次数 %d\n通赔次数 %d\n牛牛次数 %d\n胜利次数 %d"
niuniu_str_table.close_vip_room = "是否请求解散房间"
niuniu_str_table.sure_close_vip_room = "玩家%s请求解散房间"