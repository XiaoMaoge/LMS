--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

-- 公告内容
cc.exports.NoticeContent = { }

-- 更新公告
NoticeContent.updataContentTitle = ""
NoticeContent.updataContent1 = "更新内容"       -- 更新内容1
NoticeContent.updataContent2 = "1.  修复已知BUG；"       -- 更新内容1
-- NoticeContent.updataContent3 = "2.  界面布局重新分配，功能清晰可见；"       -- 更新内容2
-- NoticeContent.updataContent4 = "3.  吃碰杠按钮优化，醒目方便点击；"       -- 更新内容3
-- NoticeContent.updataContent5 = "4.  游戏卡顿BUG修复；"       -- 更新内容4
-- NoticeContent.updataContent6 = "5.  修复已知BUG，优化部分界面；"       -- 更新内容5

-- 普通公告
NoticeContent.commonContentTitle = ""
NoticeContent.commonContent1 = "                                       联系我们\r\n如果您在游戏中遇到任何问题，敬请联系客服微信号：LLFJMJ\r\n\r\n                                       公告声明\r\n本游戏适合18周岁以上成年人用户，未满18周岁的用户请在家长的监督下进行游戏。 \r\n禁止任何利用本游戏平台进行赌博的行为，让我们共同净化游戏环境，一旦发现有用户违反协议，我们将立即查封账号！"       -- 公告1
NoticeContent.commonContent2 = ""       -- 公告2
NoticeContent.commonContent3 = ""       -- 公告3

--endregion
